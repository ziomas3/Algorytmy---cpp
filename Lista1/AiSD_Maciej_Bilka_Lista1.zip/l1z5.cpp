#include <iostream>

struct lnode
{
    int key;
    lnode *next;
};

int nty(int n, lnode *l)
{
     int i = 1; 
      
    if(i == n) 
    return l->key; 
    if (l->next==NULL) return 0;
    return nty(n-1, l->next);  
}

int main()
{
    return 0;
}